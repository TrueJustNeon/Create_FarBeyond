ServerEvents.recipes(event => {
    event.stonecutting(
        item.of('kubejs:brass_machine'), // Input??
        item.of('create:brass_funnel', 2) // Output??

    )
})
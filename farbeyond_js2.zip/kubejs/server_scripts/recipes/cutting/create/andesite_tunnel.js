ServerEvents.recipes(event => {
    event.stonecutting(
        item.of('kubejs:andesite_machine'), // Input??
        item.of('create:andesite_tunnel', 2) // Output??

    )
})
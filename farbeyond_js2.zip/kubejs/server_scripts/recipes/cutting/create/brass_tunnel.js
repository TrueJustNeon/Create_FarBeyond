ServerEvents.recipes(event => {
    event.stonecutting(
        item.of('kubejs:brass_machine'), // Input??
        item.of('create:brass_tunnel', 2) // Output??

    )
})
// Assembly, smithing, etc goes here.
ServerEvents.recipes(event => {
  event.shaped('kubejs:sap', [
    'LLL',
    'LWL',
    'LLL'
  ], {
    W: 'create:copper_casing',
    L: 'create:factory_logistics:fluid_mechanism'
})
})
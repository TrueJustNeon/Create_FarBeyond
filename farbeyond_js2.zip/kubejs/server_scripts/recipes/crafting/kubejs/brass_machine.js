// Assembly, smithing, etc goes here.
ServerEvents.recipes(event => {
  event.shaped('kubejs:sap', [
    'LLL',
    'LWL',
    'LLL'
  ], {
    W: 'create:brass_casing',
    L: 'create:precision_mechanism'
})
})
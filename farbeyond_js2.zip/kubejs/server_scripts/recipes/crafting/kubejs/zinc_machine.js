// Assembly, smithing, etc goes here.
ServerEvents.recipes(event => {
  event.shaped('kubejs:sap', [
    'LLL',
    'LWL',
    'LLL'
  ], {
    W: 'thermal:machine_frame',
    L: 'powergrid:electrical_gizmo'
})
})